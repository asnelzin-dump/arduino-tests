#define RxD 6
#define TxD 7

#define LEFT_SERVO_PIN 10
#define RIGHT_SERVO_PIN 9

#define LEFT_LED_PIN 12
#define RIGHT_LED_PIN 11
#define FRONT_LED_PIN 8

#define LEFT_SENSOR_PIN A4
#define RIGHT_SENSOR_PIN A5
#define FRONT_SENSOR_PIN A3